#ifndef __DEFINITIONS
#define __DEFINITIONS

#define BORDER      0x20   /* 6th bit */
#define UNWRAPPED   0x40   /* 7th bit */
#define POSTPONED   0x80   /* 8th bit */

#endif