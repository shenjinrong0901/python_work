#ifndef __GETMASK
#define __GETMASK

void GetMask(FILE *mfp, char *bmaskfile, unsigned char **bitflags, int xsize, int ysize);

#endif