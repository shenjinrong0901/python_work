#ifndef __GRAD
#define __GRAD
float Gradient(float, float);
#endif
